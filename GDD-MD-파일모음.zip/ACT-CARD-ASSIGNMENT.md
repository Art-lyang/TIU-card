# TERMINAL SESSION — 카드 Act 배분표 v3

> 최종 업데이트: 2026-04-08 (321장 반영)

## 파일 구조

| 파일 | 변수명 | 카드 수 | 내용 |
|------|--------|--------|------|
| data-cards-1.js | CARDS_BASE | 51 | 공통 운영 (Core 11 + Act1 7 + 1→2 13 + Act2 29 + 2→3 17 등) |
| data-cards-2.js | CARDS_STORY | 39 | 스토리 진행 (프로메 + 서하은 + ORACLE + 엔딩 루트 접근) |
| data-cards-3.js | CARDS_ENDING | 28 | 엔딩 루트 카드 (CE-001~028, day 최소 조건 포함) |
| data-cards-4.js | CARDS_INVESTIGATE | 12 | 이변체 연쇄 (관찰5 + 결정5 + 미조우2) |
| data-cards-5.js | CARDS_RESOURCE | 14 | 자원 회복 + 일반 운영 + 후속 |
| data-cards-6.js | CARDS_ACT1_DAILY | 22 | Act 1 일상 (보급/인사/시설/순찰/날씨/통신/훈련) |
| data-cards-7.js | CARDS_ACT2_DAILY | 20 | Act 2 일상 (보급지연/연구/정비/봉쇄/날씨/자원회복) |
| data-cards-8.js | CARDS_TRANSITION | 11 | 전환 루트 전용 (CT-001~011) |
| data-cards-9.js | CARDS_HAEUN | 11 | 서하은 분기 (CS-001~015) |
| data-cards-10.js | CARDS_EXTRA | 20 | 추가 카드 (C-157~176) |
| data-cards-11.js | CARDS_CHAINS | 13 | 연계 체인 이벤트 (C-179~192) |
| data-cards-12.js | CARDS_NEW_A | 20 | Act 1~2 신규 (C-193~214) |
| data-cards-13.js | CARDS_NEW_B | 20 | Act 2~3 신규 (C-213~232) |
| data-cards-14.js | CARDS_ACT3 | 15 | Act 3 보강 (C-233~247) |
| data-cards-15.js | CARDS_EXTERNAL | 12 | 외부 인물 (C-248~260) |

---

## Act별 활성 카드 풀

| Act | 풀 크기 | 구성 |
|-----|--------|------|
| **Act 1** | ~75장 | Core + Act1 전용 + 1→2 공유 + Daily + Extra(Act1) + New12(Act1) |
| **Act 2** | ~170장 | Core + 1→2 + Act2 전용 + 2→3 + Daily + Transition + Investigate + Extra + New12 + New13 + Chain Events |
| **Act 3** | ~100장 | Core + 2→3 + Act3 전용 + Ending + Haeun + Act3 Extra + External + New13(Act3) |

---

## Core 카드 (11장) — 전 Act 활성

| ID | 내용 |
|----|------|
| C-001 | 신규 요원 배치 |
| C-002 | 민간인 접근 |
| C-004 | 의료 물자 부족 |
| C-009 | 사기 저하 |
| C-012 | 민간 뉴스 보안 위험 |
| C-023 | 식수 정화 시설 |
| C-024 | 야간 요원 언쟁 |
| C-025 | 폭우 보급로 차단 (tag: weather) |
| C-027 | 수면 부족 |
| C-048 | 신원불명 배회자 |
| C-049 | 위기 대응 훈련 |

---

## 이변체 연쇄 (12장, data-cards-4.js)

v0.5 흐름 변경: 조우 → 결정(미션) → [포획 시] 관찰

| ID | 이변체 | 단계 | req 변경 |
|----|--------|------|---------|
| C-091 | Blood Pit | 관찰 | LOG-RES-012 필요 (포획 시에만) |
| C-092 | Shell Talker | 관찰 | LOG-RES-011 필요 |
| C-093 | Mannequin | 관찰 | LOG-RES-001 필요 |
| C-094 | Brood Drone | 관찰 | trust.doyun ≥ 50 |
| C-095 | Spore Phantom | 관찰 | trust.sejin ≥ 55 |
| C-096~100 | 5종 각 1장 | 결정 | 기본 LOG만 필요 (관찰 LOG 불필요) |
| C-177 | 미조우 Act2 진입 | 특수 | 이변체 미접촉 시 |
| C-178 | 잔해 분석 | 특수 | LOG-060 후속 |

---

## 연계 체인 (13장, data-cards-11.js)

| 체인 | 카드 ID | 트리거 LOG | 내용 |
|------|---------|-----------|------|
| 신규요원 훈련 | C-179~183 | LOG-062, LOG-GYM 등 | 훈련→성공/실패→부상→습격 |
| 식수 오염 | C-184~186 | LOG-066~068 | 식중독→요원 감소→ORACLE 경고 |
| 야간 습격 | C-188~192 | LOG-070~073 | 야간 습격→강도윤 생존/사망 분기 |

---

## 외부 인물 (12장, data-cards-15.js)

| ID | 인물 | 내용 | 핵심 LOG |
|----|------|------|---------|
| C-248~250 | 닉 포스터 | 접촉→데이터 수령→인텔 공유 | LOG-081 |
| C-081, C-252~253 | 박소영 | 합류→보고→정체 발각 | LOG-082~083 |
| C-254~260 | 에이전트 강 | 관찰 흔적만 (정체 미공개) | — |

---

## 연쇄 카드 배분

| 연쇄 | 트리거 | Act | 카드 수 |
|------|--------|-----|--------|
| CH-001 서하은의 조사 | C-008 왼쪽 | 1→2 | 2장 |
| CH-002 봉쇄 위기 | C-013 오른쪽 | 1→2 | 2장 |
| CH-003 ORACLE의 시험 | C-015 오른쪽 | 1→2 | 2장 |
| CH-004 탈북자 | C-051 왼쪽 | 2 | 2장 |
| CH-005 프로메테우스 접선 | C-058 왼쪽 | 3 | 3장 |
| CH-006 서하은의 마지막 밤 | C-074 왼쪽 | 3 | 2장 |

---

## 미션 배분

| 미션 | 트리거 | Act | 선택지 |
|------|--------|-----|--------|
| M-001 Blood Pit | C-096 | 1,2 | 제거/포획/ORACLE |
| M-002 Shell Talker | C-097 | 1,2 | 제거/포획/ORACLE |
| M-003 미분류 흔적 | C-042 left | 2 | 산/마을/ORACLE |
| M-004 Mannequin | C-098 | 2 | 제거/포획/ORACLE |
| M-005 Brood Drone | C-099 | 2 | 분산/수색/ORACLE |
| M-006 Spore Phantom | C-100 | 2 | 다양 |
| M-007 결정적 타격 | CE 카드 (GI≥40) | 3 | 전원출격/정찰/ORACLE전술 |
| M-008 관측중지 | CE 카드 (GI≤30) | 3 | 구역진입/외곽계측/ORACLE원격 |

---

## 배분 요약

| 구분 | 카드 수 |
|------|--------|
| Core (전 Act) | 11 |
| Act 1 전용 | 7 |
| Act 1→2 공유 | 13 |
| Act 2 전용 | 29 |
| Act 2→3 공유 | 17 |
| Act 3 전용 | 10 |
| Act 1 Daily | 22 |
| Act 2 Daily | 20 |
| 이변체 연쇄 | 12 |
| 자원/일반 | 14 |
| 엔딩 루트 | 28 |
| 전환 루트 | 11 |
| 서하은 분기 | 11 |
| 추가 카드 (10) | 20 |
| 연계 체인 (11) | 13 |
| Act 1~2 신규 (12) | 20 |
| Act 2~3 신규 (13) | 20 |
| Act 3 보강 (14) | 15 |
| 외부 인물 (15) | 12 |
| 체인 카드 | 13 |
| **총계** | **321** |
